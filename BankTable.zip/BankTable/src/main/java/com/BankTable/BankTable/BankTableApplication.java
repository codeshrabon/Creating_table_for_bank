package com.BankTable.BankTable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankTableApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankTableApplication.class, args);
	}

}
